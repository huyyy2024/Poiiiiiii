package com.firebow.event;

import com.firebow.util.*;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * FireBowRuntime v6 — rail là một job có state machine.
 *
 *   SEND   : chờ rotation tick này được áp → interact rail
 *   VERIFY : rail phải sống đủ "window" tick (≈ ping/50 + 2) để server kịp revert nếu từ chối.
 *            rail mất → quay lại SEND (tối đa MAX_PLACE_ATTEMPTS lần)
 *   CART   : rail đã ổn định → đặt TNT minecart. Xong thì kết thúc job.
 *
 * Mọi thao tác đều chạy trên main thread (arrow tick + END_CLIENT_TICK).
 */
public final class FireBowRuntime {

    private static final FireBowRuntime INSTANCE = new FireBowRuntime();
    public static FireBowRuntime get() { return INSTANCE; }

    private static final long ARROW_TTL          = 3000L;
    private static final int  MAX_PLACE_ATTEMPTS = 4;
    private static final int  MAX_WAIT          = 3;    // tick chờ trước khi bỏ bước hiện tại
    private static final int  MAX_JOB_TICKS     = 80;   // hết giờ cho cả job

    /**
     * true: đặt cart ngay trong END tick đã đặt rail, không chờ tick sau.
     * Rail được client dự đoán ngay; cart chỉ cần rail có mặt phía client. Tiết kiệm 1 tick.
     * Đặt false để quay lại hành vi v35 (cart tick sau).
     */
    private static final boolean SAME_TICK_CART = true;

    /**
     * Refill cart: khi hotbar không còn TNT minecart và túi có, chuyển một cart sang ô trống trong hotbar.
     * BẬT (v42). Gửi gói ClickSlot khi KHÔNG mở GUI, là kiểu hành vi mà AC hay kiểm tra
     * (inventory click ngoài màn hình). Chỉ bật khi bạn chấp nhận rủi ro đó và test riêng.
     */
    private static final boolean REFILL_CART = true;
    // TNT minecart không xếp chồng (max stack 1): mỗi lần refill chỉ chuyển ĐÚNG MỘT cart.
    // Cooldown ngắn để cart kế tiếp sẵn sàng ngay sau khi cart trước được đặt.
    private static final int     REFILL_COOLDOWN_TICKS = 2;
    private int refillCooldown = 0;

    private enum Phase { SEND, CART }

    private static final class RailJob {
        final BlockPos pos;
        Phase phase      = Phase.SEND;
        int   attempts   = 0;  // số lần đã gửi interact
        int   ticks      = 0;  // tick đếm trong phase hiện tại
        int   window     = 0;  // số tick rail phải sống trước khi đặt cart
        int   totalTicks = 0;

        RailJob(BlockPos pos) { this.pos = pos; }
    }

    private final Map<Integer, Long> acceptedArrows = new ConcurrentHashMap<>();
    private volatile boolean enabled = true;
    private RailJob job = null;  // chỉ đọc/ghi trên main thread

    private FireBowRuntime() {}

    public boolean isEnabled() { return enabled; }
    public void    toggle()    { enabled = !enabled; }
    public boolean isBusy()    { return job != null; }

    public boolean isDuplicateArrow(int id) {
        Long t = acceptedArrows.get(id);
        return t != null && (System.currentTimeMillis() - t) < ARROW_TTL;
    }

    // ─── HEAD sendMovementPackets: áp góc để movement packet mang đúng rotation ──

    public void beforeSync() {
        if (!enabled) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        RotationUtil.applyBeforeSync(mc.player);
    }

    // ─── Arrow tick: nhận yêu cầu đặt rail ──────────────────────────────────

    public void requestRail(MinecraftClient mc, int arrowId, BlockPos railPos) {
        if (job != null) return;
        if (InventoryUtil.findAny(Items.RAIL, Items.POWERED_RAIL).isMissing()) return;

        acceptedArrows.put(arrowId, System.currentTimeMillis());
        AsyncRunner.runDelayed(() -> acceptedArrows.remove(arrowId), ARROW_TTL);

        job = new RailJob(railPos);
        InteractionUtil.prepareRailPlacement(mc, railPos);
    }

    // ─── END_CLIENT_TICK ─────────────────────────────────────────────────────

    public void onClientTick(MinecraftClient mc) {
        try {
            if (mc.player == null || mc.world == null) {
                job = null;
                return;
            }
            if (!enabled) {
                if (job != null) abort(mc);
                return;
            }
            tryRefillCart(mc);
            if (job != null) stepJob(mc);
        } finally {
            RotationUtil.endOfTick();
        }
    }

    /** Chuyển một TNT minecart từ túi sang ô trống trong hotbar khi hotbar hết cart. Không chạy khi đang có job. */
    private void tryRefillCart(MinecraftClient mc) {
        if (!REFILL_CART) return;
        if (refillCooldown > 0) { refillCooldown--; return; }

        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null) return;     // đang mở GUI thì không làm
        if (job != null || p.isUsingItem()) return;

        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < 9; i++) {
            if (inv.getStack(i).isOf(Items.TNT_MINECART)) return;   // hotbar còn cart
        }

        int emptyHotbar = -1;
        for (int i = 0; i < 9; i++) {
            if (inv.getStack(i).isEmpty()) { emptyHotbar = i; break; }
        }
        if (emptyHotbar < 0) return;               // hotbar đầy, không tự sắp xếp

        int src = -1;
        for (int i = 9; i < 36; i++) {             // túi chính: slot 9..35 trùng index trong PlayerScreenHandler
            if (inv.getStack(i).isOf(Items.TNT_MINECART)) { src = i; break; }
        }
        if (src < 0) return;

        mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, src, emptyHotbar, SlotActionType.SWAP, p);
        refillCooldown = REFILL_COOLDOWN_TICKS;
    }

    private void stepJob(MinecraftClient mc) {
        RailJob j = job;
        j.ticks++;
        j.totalTicks++;
        if (j.totalTicks > MAX_JOB_TICKS) { abort(mc); return; }

        boolean railThere = isRail(mc, j.pos);

        switch (j.phase) {
            case SEND -> {
                // Rail đã có (placed tick trước) → thẳng CART ngay
                if (railThere) { enter(j, Phase.CART, 0); return; }

                SearchResult rail = InventoryUtil.findAny(Items.RAIL, Items.POWERED_RAIL);
                if (rail.isMissing()) { abort(mc); return; }

                switch (InteractionUtil.executeRail(mc, j.pos, rail.slot)) {
                    case SENT      -> {
                        j.attempts++;
                        if (SAME_TICK_CART && isRail(mc, j.pos)) {
                            SearchResult cart = InventoryUtil.findItem(Items.TNT_MINECART);
                            if (!cart.isMissing() && InteractionUtil.placeCartDirect(mc, j.pos, cart.slot)) {
                                job = null;
                                return;
                            }
                        }
                        enter(j, Phase.CART, 0);
                    }
                    case NOT_READY -> { if (j.ticks > MAX_WAIT) abort(mc); }
                    case INVALID   -> abort(mc);
                }
            }

            case CART -> {
                // Rail biến mất → server revert → thử đặt lại
                if (!railThere) { revert(mc, j); return; }

                SearchResult cart = InventoryUtil.findItem(Items.TNT_MINECART);
                if (cart.isMissing()) { job = null; return; }

                if (InteractionUtil.placeCartDirect(mc, j.pos, cart.slot)) {
                    job = null;
                } else if (j.ticks > MAX_WAIT) {
                    abort(mc);
                }
            }
        }
    }

    /** Rail bị server revert → đặt lại từ đầu, hoặc bỏ nếu đã hết lượt. */
    private void revert(MinecraftClient mc, RailJob j) {
        if (j.attempts >= MAX_PLACE_ATTEMPTS) { abort(mc); return; }
        InteractionUtil.prepareRailPlacement(mc, j.pos);
        enter(j, Phase.SEND, 0);
    }

    private static void enter(RailJob j, Phase phase, int window) {
        j.phase  = phase;
        j.ticks  = 0;
        j.window = window;
    }

    private void abort(MinecraftClient mc) {
        job = null;
        InteractionUtil.abort(mc);
    }

    private static boolean isRail(MinecraftClient mc, BlockPos pos) {
        BlockState s = mc.world.getBlockState(pos);
        return s.isOf(Blocks.RAIL) || s.isOf(Blocks.POWERED_RAIL);
    }


}
